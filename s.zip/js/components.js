async function loadComponent(elementId, file) {
    const element = document.getElementById(elementId);

    if (!element) return;

    try {
        const response = await fetch(file + "?v=2");

        if (!response.ok) {
            throw new Error(`Nie udało się wczytać ${file}`);
        }

        const html = await response.text();

        console.log("WCZYTANY KOMPONENT:", file);
        console.log(html);

        element.innerHTML = html;

    } catch (error) {
        console.error(error);

        element.innerHTML =
            `<p class="component-error">
                Nie udało się wczytać elementu strony.
            </p>`;
    }
}