
document.addEventListener("DOMContentLoaded", () => {

    const images = document.querySelectorAll(".gallery-item img");

    if (!images.length) return;

    // Tworzenie okna podglądu
    const lightbox = document.createElement("div");
    lightbox.className = "lightbox";
    lightbox.setAttribute("role", "dialog");
    lightbox.setAttribute("aria-modal", "true");
    lightbox.setAttribute("aria-label", "Podgląd zdjęcia");

    lightbox.innerHTML = `
        <button class="lightbox-close" aria-label="Zamknij">&times;</button>
        <button class="lightbox-prev" aria-label="Poprzednie zdjęcie">&#10094;</button>
        <img class="lightbox-image" src="" alt="">
        <button class="lightbox-next" aria-label="Następne zdjęcie">&#10095;</button>
    `;

    document.body.appendChild(lightbox);

    const preview = lightbox.querySelector(".lightbox-image");
    const closeButton = lightbox.querySelector(".lightbox-close");
    const prevButton = lightbox.querySelector(".lightbox-prev");
    const nextButton = lightbox.querySelector(".lightbox-next");

    let currentIndex = 0;

    const openLightbox = (index) => {
        currentIndex = index;
        updateImage();
        lightbox.classList.add("active");
        document.body.classList.add("lightbox-open");
        closeButton.focus();
    };

    const closeLightbox = () => {
        lightbox.classList.remove("active");
        document.body.classList.remove("lightbox-open");
    };

    const updateImage = () => {
        const image = images[currentIndex];
        preview.src = image.src;
        preview.alt = image.alt;
    };

    const showNext = () => {
        currentIndex = (currentIndex + 1) % images.length;
        updateImage();
    };

    const showPrevious = () => {
        currentIndex = (currentIndex - 1 + images.length) % images.length;
        updateImage();
    };

    images.forEach((image, index) => {
        image.addEventListener("click", () => openLightbox(index));
        image.style.cursor = "zoom-in";
    });

    closeButton.addEventListener("click", closeLightbox);
    nextButton.addEventListener("click", showNext);
    prevButton.addEventListener("click", showPrevious);

    lightbox.addEventListener("click", (event) => {
        if (event.target === lightbox) closeLightbox();
    });

    document.addEventListener("keydown", (event) => {
        if (!lightbox.classList.contains("active")) return;

        if (event.key === "Escape") closeLightbox();
        if (event.key === "ArrowRight") showNext();
        if (event.key === "ArrowLeft") showPrevious();
    });

});
